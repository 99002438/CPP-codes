#include "point.h"
#include <iostream>
#include <list>
class STLPoint {
  std::list<Point> points;

public:
  void addPoint(int, int);
  void displayAll();
  int countAll(Quadrant);
  int countAllPoints() { return points.size(); }
  int displayPointOnCircle(int);
  int displayPointinCircle(int);
};
