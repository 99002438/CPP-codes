#ifndef __BOOK_H
#define __BOOK_H

#include <string>
#include <iostream>

class Contact {
  std::string first_name;
  std::string last_name;
  std::string prim_num;
  std::string sec_num;

public:
Contact(std::string, std::string, std::string, std::string);
void display() const;
std::string getFirstname() const;
std::string getLastname() const;
std::string setFirstname(std::string fname) {first_name=fname;}
std::string setLastname(std::string lname) {last_name=lname;}
std::string getPrimnum() const;
std::string getSecnum() const;
bool operator==(const Contact& ref);
friend std::ostream& operator<< (std::ostream& rout, const Contact& rb);
};


#endif
