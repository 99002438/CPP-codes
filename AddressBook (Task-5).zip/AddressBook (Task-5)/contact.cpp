#include"contact.h"
Contact::Contact(std::string fname, std::string lname, std::string pnum, std::string snum):first_name(fname),last_name(lname),prim_num(pnum),sec_num(snum){
}

void Contact::display() const{
std::cout<<first_name<<","<<last_name<<","<<prim_num<<","<<sec_num<<"\n";
}

std::string Contact::getFirstname() const{return first_name;}
std::string Contact::getLastname() const{return last_name;}
std::string Contact::getPrimnum() const{ return prim_num;}
std::string Contact::getSecnum() const{return sec_num;}
bool Contact::operator==(const Contact& ref){
if(prim_num==ref.prim_num)
return true;
else return false;
}
std::ostream& operator<< (std::ostream& rout, const Contact& rb){
rout<<rb.first_name<<","<<rb.last_name<<","<<rb.prim_num<<","<<rb.sec_num<<"\n";
  return rout;
}
