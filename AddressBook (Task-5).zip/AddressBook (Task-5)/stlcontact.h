
#include "contact.h"
#include <list>
#include <algorithm>
class StlContact {
  std::list<Contact> contacts;

public:
void addContact(std::string , std::string,std::string , std::string);
void displayAll() ;
Contact* findCustomerByName(std::string,std::string);
Contact* findCustomerById(std::string);
void removeContact(std::string);
void updateContactdetails(std::string,std::string,std::string);
int countAll(){return contacts.size();}
};
