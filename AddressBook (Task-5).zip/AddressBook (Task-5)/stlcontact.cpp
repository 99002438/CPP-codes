
#include"contact.h"
#include"stlcontact.h"
#include<iostream>
#include<list>
#include<string>

void StlContact::addContact(std::string fname, std::string lname,std::string pnum , std::string snum) {
    contacts.push_back(Contact(fname,lname,pnum,snum));

}

void StlContact::removeContact(std::string pnum)
{
std::list<Contact>::iterator iter;
  for(iter=contacts.begin();iter!=contacts.end();++iter)
	{
    	if((iter->getPrimnum()).compare(pnum)==0)
        	break;
	}
  if(iter!=contacts.end())
    contacts.erase(iter);
}

void StlContact:: displayAll() {
    std::list<Contact>::iterator iter;
   for(iter=contacts.begin();iter!=contacts.end();++iter)
       iter->display();
}


Contact* StlContact:: findCustomerById(std::string pnum) {

     std::list<Contact>::iterator iter;
   for(iter=contacts.begin();iter!=contacts.end();++iter){
    if(iter->getPrimnum()==pnum)
        return &(*iter);
	}
  return NULL;
}

Contact* StlContact:: findCustomerByName(std::string fname, std::string lname) {

     std::list<Contact>::iterator iter;
   for(iter=contacts.begin();iter!=contacts.end();++iter){
    if((iter->getPrimnum()==fname )||(iter->getPrimnum()==lname))
        return &(*iter);
	}
  return NULL;
}

void StlContact::updateContactdetails(std::string pnum,std::string fname,std::string lname)
{
std::list<Contact>::iterator iter;
   for(iter=contacts.begin();iter!=contacts.end();++iter)
    if(iter->getPrimnum()==pnum)
    {
        iter->setFirstname(fname);
        iter->setLastname(lname);
    }
}
