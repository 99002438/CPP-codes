#include "contact.h"
#include"stlcontact.h"
#include <gtest/gtest.h>
namespace {

class ContactTest : public ::testing::Test {

  protected:
    void SetUp() {
        contacts.addContact( "Harry","Eris","7845144445","8576666669" );
        contacts.addContact( "john","Paul","9874513335","9285412395");
        contacts.addContact( "Kapil","Singh","9478555555","7457123995");
    }
    void TearDown() {
    }
    StlContact contacts;
};
TEST_F(ContactTest,CountContacts) {
  EXPECT_EQ(3,contacts.countAll());
}

TEST_F(ContactTest,AddContact) {
  contacts.addContact("sagar","Sharma","9848555555","9848044446"  );
  EXPECT_EQ(4,contacts.countAll());
  Contact *ptr=contacts.findCustomerById( "9848555555" );
  EXPECT_NE(nullptr, ptr);
  EXPECT_STREQ("sagar", ptr->getFirstname().c_str());

}
TEST_F(ContactTest,RemoveContact) {
  contacts.removeContact( "9874513335" );
  EXPECT_EQ(2,contacts.countAll());
  Contact *ptr=contacts.findCustomerById( "9874513335");
  EXPECT_EQ(nullptr, ptr);
}
}

