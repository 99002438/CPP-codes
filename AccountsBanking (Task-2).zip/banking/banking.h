#include<list>
#include<iostream>
#include"account.h"
class Banking {
   std::list<Account> accounts;
   public:
   void addAccount(std::string,std::string,double);
   void removeAccountById(std::string);
   void displayAll();
   int countAll(){return accounts.size();};
   Account* findAccountById(std::string);
   double findAverageBalance();
   int countAccountsByBalanceRange(double,double);
   Account& findAccountWithMinBalance();
};
