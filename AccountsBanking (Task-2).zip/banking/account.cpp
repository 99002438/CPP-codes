#include "account.h"
#include <iostream>
Account::Account()
	 : custId(""), custName(""), accBalance(0) {}

Account::Account(std::string custId, std::string custName, double accBalance)
    : custId(custId), custName(custName), accBalance(accBalance) {}

Account::Account(const Account &ref)
    : custId(ref.custId), custName(ref.custName),
      accBalance(ref.accBalance) {}

double Account::getBalance() const {return accBalance;}

std::string Account::getId() const {return custId;}

void Account::display() const {
  std::cout << custId << "," << custName << "," << accBalance << "\n";
}

