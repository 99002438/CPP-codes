#include "banking.h"
#include"account.h"
#include <gtest/gtest.h>
namespace {

class BankingTest : public ::testing::Test {

  protected:
    void SetUp() {
        bank.addAccount("1","Vishali",5000);
        bank.addAccount("2","Swaminathan",10000);
        bank.addAccount("3","Vicky",3000);
    }
    void TearDown() {
    }
    Banking bank;
};
TEST_F(BankingTest,CountAccount) {
  EXPECT_EQ(3,bank.countAll());
}
TEST_F(BankingTest,AverageBalance) {
  EXPECT_EQ(6000,bank.findAverageBalance());
}
TEST_F(BankingTest,CountByBalanceRange) {
  EXPECT_EQ(1, bank.countAccountsByBalanceRange(8000,12000));
}
TEST_F(BankingTest,AddAccount) {
  bank.addAccount("4","Dhiwakar",7000);
  EXPECT_EQ(4,bank.countAll());
  Account *ptr=bank.findAccountById("3");
  EXPECT_NE(nullptr, ptr);
  EXPECT_STREQ("3", ptr->getId().c_str());
  EXPECT_EQ(3000, ptr->getBalance());
}
TEST_F(BankingTest,RemoveAccount) {
  bank.removeAccountById("4");
  EXPECT_EQ(3,bank.countAll());
  Account *ptr=bank.findAccountById("4");
  EXPECT_EQ(nullptr, ptr);
}
}



