#ifndef __ACCOUNT_H
#define __ACCOUNT_H

#include<string>

class Account {
  std::string custId;
  std::string custName;
  double accBalance;
  public:
  Account();
  Account(std::string,std::string,double);
  Account(const Account&);
  double getBalance() const;
  void display() const;
  std::string getId() const;
};

#endif
