#include"banking.h"
#include"account.h"
#include<list>
#include<iostream>

void Banking::addAccount(std::string id,std::string name,double bal) {
   accounts.push_back(Account(id,name,bal));
}


void Banking::displayAll() {
   std::list<Account>::iterator iter;
   for(iter=accounts.begin();iter!=accounts.end();++iter)
       iter->display();
}

double Banking::findAverageBalance(){
	std::list<Account>::iterator it;
	double sum=0;
	int count=0;
	for(it=accounts.begin();it!=accounts.end();++it){
        sum+=it->getBalance();
		count++;
	}
	return (double)sum/count;
}


Account* Banking::findAccountById(std::string Id) {
  std::list<Account>::iterator iter;
  for(iter=accounts.begin();iter!=accounts.end();++iter) {
    if(iter->getId()==Id)
        return &(*iter);
	}
  return NULL;
}


void Banking::removeAccountById(std::string Id) {
  std::list<Account>::iterator iter;
  for(iter=accounts.begin();iter!=accounts.end();++iter)
	{
    	if(iter->getId()==Id)
        	break;
	}
  if(iter!=accounts.end())
    accounts.erase(iter);
}


 Account& Banking::findAccountWithMinBalance() {
  std::list<Account>::iterator iter;
  iter=accounts.begin();
  double minBal = iter->getBalance();
  for(iter=accounts.begin();iter!=accounts.end();++iter) {
    if(iter->getBalance() < minBal) {
        minBal = iter->getBalance();
        break;
    }
  }
  return *iter;
}


int Banking::countAccountsByBalanceRange(double min,double max){
	std::list<Account>::iterator it;
	int count=0;
	for(it=accounts.begin();it!=accounts.end();++it){
		if(it->getBalance() > min && it->getBalance() < max)
        {
            count++;
        }
	}
	return count;
}




