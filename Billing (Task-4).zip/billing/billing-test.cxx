#include "billing.h"
#include "prepaid.h"
#include "postpaid.h"
#include "customer.h"

#include <gtest/gtest.h>
namespace {

class BillingTest : public ::testing::Test {

protected:
  void SetUp()
  {
    customers.addCustomer(1, "Vishali", "9894558997", 800);
    customers.addCustomer(2, "CTR", "9559648567", 400);
    customers.addCustomer(3, "Pooja", "9854698587", 200);
    customers.addCustomer(4, "Kaushik", "9658745896", 900);
    customers.addCustomer(5, "Shariq", "9568798412", 100);
  }
  void TearDown() {}
  Billing customers;
};

TEST_F(BillingTest, AddCustomerTest) {
  customers.addCustomer(6, "Mukesh", "9658213258", 100);
  EXPECT_EQ(6, customers.countAll());
}

TEST_F(BillingTest, CountTest) {
  EXPECT_EQ(5, customers.countAll());
}
TEST_F(BillingTest, FindByIdTestTrue) {
  Customer *ptr = customers.findCustomerById(1);
  EXPECT_EQ(800, ptr->getAccBalance());
  EXPECT_STREQ("Vishali", ptr->getCustName().c_str());
  EXPECT_STREQ("9894558997", ptr->getCustPhone().c_str());
}
TEST_F(BillingTest, FindByIdTestFalse) {
  Customer *ptr = customers.findCustomerById(7);
  EXPECT_EQ(NULL, ptr);
}
TEST_F(BillingTest, FindByPhoneTest) {
  Customer *ptr = customers.findCustomerByPhone("9568798412");
  EXPECT_EQ(100, ptr->getAccBalance());
  EXPECT_STREQ("Shariq", ptr->getCustName().c_str());
  EXPECT_EQ(5, ptr->getCustId());
}
TEST_F(BillingTest, AverageTest) {
  double avgBalance = customers.findAverageBalance();
  EXPECT_EQ(480, avgBalance);
}
TEST_F(BillingTest, MaxBalanceTest) {
  double maxBalance = customers.findMaxBalance();
  EXPECT_EQ(900, maxBalance);
}
TEST_F(BillingTest, CountMinBalanceTest) {
  int countMinBalance = customers.countByMinBalance(500);
  EXPECT_EQ(2, countMinBalance);
}
TEST_F(BillingTest, RemoveCustomerTest) {
  customers.removeCustomer(5);
  EXPECT_EQ(NULL, customers.findCustomerById(5));
  EXPECT_EQ(4, customers.countAll());
}

}
int main(int argc, char **argv)
    {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
    }
