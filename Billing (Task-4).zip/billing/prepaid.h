#ifndef __PREPAID_H
#define __PREPAID_H

#include<string>
#include<cstdint>

#include "customer.h"
#pragma once

class PrepaidCustomer : public Customer
 {

  void recharge(double);
  public:
  PrepaidCustomer();
  PrepaidCustomer(int,std::string,std::string,double);
  void credit(double);
  void makeCall(double);
  double getAccBalance();
  int getCustId();
  std:: string getCustName();
  std:: string getCustPhone();


};

#endif
