
#include"customer.h"
#include <iostream>

Customer::Customer(): custId(), custName(""), custPhone(""), accBalance(0.0){}

Customer::Customer(int id,std::string name,std::string phone,double bal): custId(id), custName(name), custPhone(phone), accBalance(bal){}


double Customer::getAccBalance()
{
    return accBalance;
}

void Customer::display()
{
    std:: cout <<custId <<","<<custName<<"," <<custPhone<< ","<<accBalance<< ","<<accType<<std::endl;
}


int  Customer::getCustId()
{
    return custId;
}

std:: string Customer::getCustName()
{
    return custName;
}

std:: string Customer::getCustPhone()
{
    return custPhone;
}
