
#ifndef __CUSTOMER_H
#define __CUSTOMER_H

#include<string>
#include<cstdint>

enum AccountType {
  Prepaid,
  Postpaid
};
const double callRate = 1.0;

class Customer
{
  protected:

  int custId;
  std::string custName;
  std::string custPhone;
  double accBalance;
  AccountType accType;

  public:

  Customer();
  Customer(int,std::string,std::string,double);
  virtual void credit(double)=0;
  virtual void makeCall(double)=0;
  virtual int getCustId();
  virtual std:: string getCustName();
  virtual std:: string getCustPhone();
  virtual double getAccBalance();
  void display();
};

#endif
