
#include "prepaid.h"
#include "customer.h"

PrepaidCustomer::PrepaidCustomer(): Customer(){accType = Prepaid;}
PrepaidCustomer::PrepaidCustomer(int id,std::string name,std::string phone,double bal): Customer(id,name,phone,bal){accType = Prepaid;}

void PrepaidCustomer:: credit(double amount)
{
   recharge(amount);
}

void PrepaidCustomer:: makeCall(double mins)
{
   accBalance -= mins*callRate;
}

void PrepaidCustomer:: recharge(double amount)
{
   accBalance += amount;
}


int PrepaidCustomer:: getCustId()
{
    return custId;
}

std::string PrepaidCustomer:: getCustName()
{
    return custName;
}

std::string PrepaidCustomer:: getCustPhone()
{
    return custPhone;
}

double PrepaidCustomer:: getAccBalance()
{
    return accBalance;
}

