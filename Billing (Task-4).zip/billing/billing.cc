#include "billing.h"
#include "customer.h"
#include "prepaid.h"
#include "postpaid.h"

#include <list>
#include <iterator>

void Billing::addCustomer(int id,std::string name,std::string phone,double bal)
{
    cust.push_back(PrepaidCustomer(id,name,phone,bal));
}

void Billing::removeCustomer(int id)
{
    std::list<PrepaidCustomer> :: iterator iter;
    for(iter=cust.begin();iter!=cust.end();iter++)
    {
        if(iter->getCustId()== id)
        {
           cust.erase(iter);
           break;
        }
    }
}

PrepaidCustomer* Billing:: findCustomerById(int id)
{
    std::list<PrepaidCustomer> :: iterator iter;
    for(iter=cust.begin();iter!=cust.end();iter++)
    {
        if(id == iter->getCustId())
        {
            return &(*iter);
        }
    }
    return NULL;

}

PrepaidCustomer* Billing:: findCustomerByPhone(std::string phn)
{
    std::list<PrepaidCustomer> :: iterator iter;
    for(iter=cust.begin();iter!=cust.end();iter++)
    {
        if( phn == iter->getCustPhone())
        {
            return &(*iter);
        }
    }
    return NULL;

}

double Billing:: findAverageBalance()
{
    double sum=0;
    std:: list <PrepaidCustomer> :: iterator iter;
    for(iter=cust.begin();iter!=cust.end();iter++)
    {
        sum = sum+ iter-> getAccBalance();
    }

    return sum/cust.size();

}

double Billing:: findMaxBalance()
{
    std:: list<PrepaidCustomer> :: iterator iter = cust.begin();
    auto maxBal  = iter->getAccBalance();
    iter++;
    for(;iter!=cust.end();++iter)
    {
        if(maxBal < iter->getAccBalance())
        {
            maxBal = iter->getAccBalance();
        }
    }
    return maxBal;

}

int Billing:: countByMinBalance(double min)
{
   int count=0;
   std::list <PrepaidCustomer> :: iterator iter;
   for(iter=cust.begin();iter!=cust.end();iter++)
   {
       if(iter->getAccBalance() >= min)
        count++;
   }
   return count;
}

int Billing:: countAll()
{
   return cust.size();
}

