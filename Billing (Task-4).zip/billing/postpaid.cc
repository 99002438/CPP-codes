
#include "postpaid.h"
#include "customer.h"

#include <iostream>

PostpaidCustomer::PostpaidCustomer(): Customer(){accType = Postpaid; }
PostpaidCustomer::PostpaidCustomer(int id,std::string name,std::string phone,double bal): Customer(id,name,phone,bal){accType = Postpaid;}

void PostpaidCustomer::credit(double amount)
{
    accBalance -= amount;
}

void PostpaidCustomer::makeCall(double mins)
{
    accBalance += mins;
}

int PostpaidCustomer::getCustId()
{
    return custId;
}

std::string PostpaidCustomer:: getCustName()
{
    return custName;
}

std::string PostpaidCustomer:: getCustPhone()
{
    return custPhone;
}

double PostpaidCustomer:: getAccBalance()
{
    return accBalance;
}

