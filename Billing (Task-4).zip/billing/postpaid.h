#ifndef __POSTPAID_H
#define __POSTPAID_H

#include<string>
#include<cstdint>

#include "customer.h"
#pragma once

class PostpaidCustomer : public Customer
 {

  void billPay(double);
  public:
  PostpaidCustomer();
  PostpaidCustomer(int id,std::string,std::string,double);
  void credit(double);
  void makeCall(double);
  double getAccBalance();
  int getCustId();
  std:: string getCustName();
  std:: string getCustPhone();


};

#endif
