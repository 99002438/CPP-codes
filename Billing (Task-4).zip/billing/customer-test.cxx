#include "customer.h"
#include "postpaid.h"
#include "prepaid.h"

#include <gtest/gtest.h>
namespace {

class CustomerTest : public ::testing::Test {

protected:
  void SetUp()
  {
    pre = new PrepaidCustomer(1, "Vishali", "9894558997", 2000);
    pre->makeCall(25);
    pre->credit(300);

    post = new PostpaidCustomer(2, "CTR", "9559648567", 500);
    post->makeCall(60);
    post->credit(500);
  }
  void TearDown()
  {
    delete pre;
    delete post;
  }
  Customer *pre;
  Customer *post;
};

TEST_F(CustomerTest, DefaultConstructor) {
  PrepaidCustomer c1;
  EXPECT_EQ(0.0, c1.getAccBalance());
  EXPECT_EQ(0.0, c1.getCustId());
  EXPECT_EQ(0, c1.getCustName().length());
}
TEST_F(CustomerTest, ParameterizedConstructorPre) {
  EXPECT_EQ(1, pre->getCustId());
  EXPECT_STREQ("Vishali", pre->getCustName().c_str());
  EXPECT_EQ(7, pre->getCustName().length());
  EXPECT_EQ(2275, pre->getAccBalance());
}
TEST_F(CustomerTest, ParameterizedConstructorPost) {
  EXPECT_EQ(2, post->getCustId());
  EXPECT_STREQ("CTR", post->getCustName().c_str());
  EXPECT_EQ(3, post->getCustName().length());
  EXPECT_EQ(60, post->getAccBalance());
}
TEST_F(CustomerTest, PrepaidCreditTest) {
  pre->credit(400);
  EXPECT_EQ(2675, pre->getAccBalance());
}
TEST_F(CustomerTest, PrepaidCallTest) {
  pre->makeCall(30);
  EXPECT_EQ(2245, pre->getAccBalance());
}
TEST_F(CustomerTest, PostpaidCreditTest) {
  post->credit(200);
  EXPECT_EQ(-140, post->getAccBalance());
}
TEST_F(CustomerTest, PostpaidCallTest) {
  post->makeCall(10);
  EXPECT_EQ(70, post->getAccBalance());
}

}

